'use client';
import TestConsole from './TestConsole';

export default function ConsolePage({ websiteId }) {
  return <TestConsole websiteId={websiteId} />;
}
