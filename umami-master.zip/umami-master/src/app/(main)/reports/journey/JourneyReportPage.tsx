import JourneyReport from './JourneyReport';

export default function JourneyReportPage() {
  return <JourneyReport />;
}
