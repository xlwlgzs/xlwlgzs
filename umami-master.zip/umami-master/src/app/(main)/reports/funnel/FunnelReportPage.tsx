'use client';
import FunnelReport from './FunnelReport';

export default function FunnelReportPage() {
  return <FunnelReport />;
}
