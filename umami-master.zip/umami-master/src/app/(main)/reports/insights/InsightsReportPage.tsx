'use client';
import InsightsReport from './InsightsReport';

export default function InsightsReportPage() {
  return <InsightsReport />;
}
