'use client';
import RevenueReport from './RevenueReport';

export default function RevenueReportPage() {
  return <RevenueReport />;
}
