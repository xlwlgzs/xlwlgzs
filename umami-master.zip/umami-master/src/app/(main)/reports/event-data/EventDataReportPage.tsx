'use client';
import EventDataReport from './EventDataReport';

export default function EventDataReportPage() {
  return <EventDataReport />;
}
